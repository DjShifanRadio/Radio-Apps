(function() {
    var ozoki_tc = "AXwqGmMaDPQrfV1Q",
        ozoki_os = "s.update.tritondigital.com",
        ozoki_url = "https://s.update.tritondigital.com/2/163927/analytics.js?cb\u003D1662008212366\u0026c3\u003DZeno+Radio\u0026dt\u003D1639271602866005506000\u0026si\u003DZenoAds\u0026sr\u003Dtritondigital.com\u0026c2\u003Didsync.js\u0026di\u003Dwww.zeno.fm\u0026de\u003D2\u0026ui\u003Dfdfc5bde-e5f3-4cd9-bbe9-a2b29ac05ce4\u0026pp\u003D25053\u0026md\u003D3\u0026ti\u003D386759ef-4825-4b48-be92-6c9671508a55\u0026ci\u003D163927",
        ozoki_ct = {
            "c3": "Zeno Radio",
            "si": "ZenoAds",
            "c2": "idsync.js",
            "pp": "25053",
            "ci": "163927",
            "ui": "fdfc5bde-e5f3-4cd9-bbe9-a2b29ac05ce4",
            "md": "3",
            "ti": "386759ef-4825-4b48-be92-6c9671508a55",
            "cb": "1662008212366",
            "dt": "1639271602866005506000",
            "sr": "tritondigital.com",
            "di": "www.zeno.fm",
            "de": "2"
        },
        ozoki_omid = {
            dm: "minkatu.com",
            v: "1",
            f: "json",
            e: "js"
        },
        ozoki_lep, ozoki_opt = {
            sm: 0.7397,
            xhr_ipv6: true,
            chrext: true,
            dfcs: true,
            cor: true,
            nvl: true,
            kmp: true,
            ndm: true,
            ecm: true,
            wor: true,
            hco: true,
            intgr: true,
            mouse: true,
            dup: true,
            wrip: true
        };
    var PAGESPEED_VERSION = "2.66.1";
    var xFn, fFn, bFn, postUrl;
    var k, l, m, n, a = window,
        b = a.document,
        c = a.navigator,
        d = a.encodeURIComponent,
        e = {},
        f = 0,
        g = "gif",
        i = {},
        j = !1,
        o = !1,
        p = !1,
        q = "",
        r = JSON.stringify;
    try {
        if ("undefined" == typeof ozoki_sv && (ozoki_sv = !1), F(), "undefined" == typeof ozoki_os) {
            var p = !0,
                s = "",
                t = "",
                u = "pagespeed.js";
            if (document.currentScript) s = document.currentScript.src.split("?")[1], o = 0 < document.currentScript.integrity.length, t = document.currentScript.src.substr(0, document.currentScript.src.indexOf(":")), q = document.currentScript.src.substr(0, document.currentScript.src.lastIndexOf("/"));
            else {
                var v = document.scripts[document.scripts.length - 1];
                if (-1 < v.src.indexOf(u)) s = v.src.split("?")[1], "undefined" != typeof v.integrity && (o = 0 < v.integrity.length), t = v.src.substr(0, v.src.indexOf(":")), q = v.src.substr(0, v.src.lastIndexOf("/"));
                else
                    for (var w = document.querySelectorAll("script"), x = 0; x < w.length; x++)
                        if (-1 < (v = w[x]).src.indexOf(u)) {
                            s = v.src.split("?")[1], "undefined" != typeof v.integrity && (o = 0 < v.integrity.length), t = v.src.substr(0, v.src.indexOf(":")), q = v.src.substr(0, v.src.lastIndexOf("/"));
                            break
                        }
            }
            if (!s) throw new Error("Cannot locate config vars");
            for (var B, y = {}, z = s.split("&"), A = 0; A < z.length; A++) z[A] && (B = z[A].split("="), y[d(B[0])] = d(B[1]));
            if (!y.dom) throw new Error("Insufficient Config Vars");
            ! function o(t, i, n) {
                var t = t + "://" + i + "/o/config.json?" + n,
                    e = new XMLHttpRequest;
                try {
                    e.onreadystatechange = function() {
                        if (4 === e.readyState && 200 == e.status) {
                            var o = (o = e.responseText.split("\\x3D").join("=")).split("\\x26").join("&"),
                                o = JSON.parse(o);
                            if (o.shi) throw new Error("Dead.");
                            ! function o(t) {
                                PAGESPEED_VERSION = p ? "2.66.1" : t.PAGESPEED_VERSION, ozoki_tc = t.ozoki_tc, ozoki_os = t.ozoki_os, ozoki_url = t.ozoki_url, ozoki_ct = t.ozoki_ct, "undefined" != typeof t.ozoki_dt && (ozoki_dt = t.ozoki_dt), "undefined" != typeof t.ozoki_omid && (ozoki_omid = t.ozoki_omid), ozoki_opt = t.ozoki_opt, ozoki_lep = t.ozoki_lep
                            }(o), Q()
                        }
                    }, e.open("GET", t, !0), "function" == typeof e.overrideMimeType && e.overrideMimeType("application/json"), e.send("")
                } catch (o) {}
            }(t, y.dom, s)
        }
    } catch (o) {}

    function E(o) {
        var t = new Image;
        t.src = o, t.style.visibility = "hidden", t.style.width = "1px", t.style.height = "1px", b.body.appendChild(t)
    }

    function F() {
        return Date.now ? Date.now() : (new Date).getTime()
    }

    function G(o) {
        var t = F();
        E(n + "y." + g + "?en=" + d(o.name) + "&em=" + d(o.message) + "&es=" + d(o.stack) + "&ets=" + d(t) + "&" + m)
    }

    function L(o) {
        return {
            loader: o
        }
    }

    function O() {
        var s, u, t;
        j || (i.ozoki_mn = function o() {
            var t = ozoki_url.substr(0, ozoki_url.indexOf(":")) + "://" + ozoki_os + "/2/" + PAGESPEED_VERSION + "/",
                i = "main.js",
                n = (p && (t = q + "/"), {
                    default: "",
                    cb: "?cb=" + ozoki_tc
                });
            return ozoki_sv && (n.default = "?sv=1", n.cb += "&sv=1"), ozoki_ct.oz_cb ? t + i + n.cb : t + i + n.default
        }(), u = i.ozoki_mn, b && !k && (k = b.createElement("script"), t = F(), k.onload = function() {
            return xFn(L({
                load: F() - t
            }))
        }, k.onerror = function() {
            return xFn(L({
                error: F() - t
            }))
        }, function o(t) {
            var n, e = ".".length,
                r = (c = 8 * e, isNaN(n = u.substr(u.indexOf(".") + e, c)) ? n : u.substr(e - 1, c)),
                c = isNaN(n = u.substr(u.indexOf(".") + e, e)) ? n : u.substr(e - 1, e);
            i.ozoki_onf = void 0 === t.onfocus || void 0, (s = i.ozoki_onf ? s : {
                toString: function() {
                    return null
                }
            })[c] = function(o) {
                if (o == r) return i
            }, t.onfocus = function() {
                return s
            }
        }(k), k.src = i.ozoki_mn, o && (k.integrity = "sha256-Qcf3fLVk4gAp1TCEoWo/G6PaSfLSwIxhBYSlAg3JqvQ=", k.crossOrigin = "anonymous")), b.body ? (j = !0, b.body.appendChild(k)) : a.setTimeout(O, 4))
    }

    function Q() {
        l = ozoki_url.substr(0, ozoki_url.indexOf(":")) + "://" + ozoki_os, m = function o() {
                var t, i = ["oz_pl=1"];
                for (t in ozoki_ct) ozoki_ct.hasOwnProperty(t) && i.push(d(t) + "=" + d(ozoki_ct[t]));
                return i
            }().join("&"), n = l + "/2/" + ozoki_ct.ci + "/" + ozoki_tc + "/", postUrl = function o() {
                return [l, "2", PAGESPEED_VERSION, ozoki_ct.ci, ozoki_tc, "postback?" + m].join("/")
            }(),
            function o() {
                var t = !!a.chrome,
                    i = !!a.URL,
                    n = !!a.v8Locale;
                if (t && i && !n) return f = 1;
                var r = !(void 0 === a.mozInnerScreenX),
                    s = !!b.contains,
                    u = !!a.HTMLBlockquoteElement,
                    d = !!c.registerProtocolHandler;
                if (!t && !r && s && !u && !d && i) return f = 2;
                var p = !!b.documentMode,
                    _ = !!a.SVGFilterElement;
                if (p && _) return f = 3;
                var k = !!a.crypto && !!a.crypto.getRandomValues,
                    l = !(void 0 === a.orientation),
                    z = !!a.visualViewport;
                return r && !l && k ? f = 4 : r && l && z ? f = 5 : !t && !n && i && z ? f = 6 : void(e = {
                    ch: t,
                    url: i,
                    v8l: n,
                    mpc: r,
                    dct: s,
                    hbe: u,
                    rph: d,
                    dmo: p,
                    sfe: _,
                    cgrv: k,
                    o: l,
                    vv: z,
                    ex: f,
                    ts: F()
                })
            }() ? function o() {
                if (void 0 === b[ozoki_tc]) b[ozoki_tc] = !1;
                else if (!ozoki_opt.dup) return;
                if (b[ozoki_tc]) return 1;
                b[ozoki_tc] = !0
            }() ? xFn(L({
                init: 0,
                dup: !0
            })) : (xFn(L({
                init: 1,
                sup: f
            })), function o() {
                i.PAGESPEED_VERSION = PAGESPEED_VERSION, i.API_VERSION = "2", i.ozoki_st = F(), i.ozoki_os = ozoki_os, i.ozoki_url = ozoki_url, i.ozoki_tc = ozoki_tc, "undefined" != typeof ozoki_dt && (i.ozoki_dt = ozoki_dt), i.ozoki_ct = ozoki_ct, i.ozoki_opt = ozoki_opt, i.ozoki_omid = ozoki_omid, i.ozoki_lep = ozoki_lep, i.ozoki_sv = ozoki_sv, i.ozoki_spt = b.currentScript || null
            }(), O(), function o() {
                a.$$$ || (a.$$$ = {}), a.$$$.setHumanConfig = function(o) {
                    i.ai_config = o
                }
            }()) : function o(t) {
                var i = "";
                try {
                    i = JSON.stringify(t)
                } catch (o) {}
                E(n + "u." + g + "?init=0&sup=" + d(i) + "&" + m)
            }(e)
    }
    xFn = function(o) {
        try {
            var t = postUrl + "&_x=1",
                i = new XMLHttpRequest;
            i.open("POST", t, !0), i.withCredentials = !1, i.setRequestHeader("Content-Type", "text/plain"), "function" == typeof i.overrideMimeType && i.overrideMimeType("text/plain"), i.send(r(o))
        } catch (o) {}
    }, fFn = function(o) {
        try {
            var t = postUrl + "&_f=1";
            fetch(t, {
                method: "POST",
                keepalive: !0,
                body: r(o)
            }).catch(function(o) {
                G(o)
            })
        } catch (o) {
            G(o)
        }
    }, bFn = function(o) {
        try {
            var t = postUrl + "&_b=1";
            navigator.sendBeacon(t, r(o))
        } catch (o) {
            G(o)
        }
    };
    try {
        p || Q()
    } catch (o) {
        G(o)
    }
})();