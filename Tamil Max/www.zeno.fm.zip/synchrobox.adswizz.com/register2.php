var com_adswizz_register_PROTOCOL_VERSION = '2.2.0';

if (typeof com_adswizz_synchro_listenerid === 'undefined') {
    var com_adswizz_synchro_listenerid = '4027c78e08aec4c1018cd6a7c5bcbfbe';
}
else {
    com_adswizz_synchro_listenerid = '4027c78e08aec4c1018cd6a7c5bcbfbe';
}

if (typeof com_adswizz_synchro_listnerid === 'undefined') {
    var com_adswizz_synchro_listnerid = com_adswizz_synchro_listenerid; // backwards compatibility
}
else {
    com_adswizz_synchro_listnerid = com_adswizz_synchro_listenerid; // backwards compatibility
}
var aw_0_req_gdpr = false;
var us_privacy = '';