if (typeof(tritonIdSync) != "object" || typeof(tritonIdSync.load_pixel) != "function") {
    var tritonIdSync = {
        load_pixel: function(src) {
            var img;
            if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
                img = new Image();
            } else {
                img = document.createElement('img');
            }
            img.src = src;
            img.width = 0;
            img.height = 0;
            img.className = "triton-pixel";
            document.body.appendChild(img);
        },
        load_script: function(src) {
            var js = document.createElement('script');
            js.type = 'text/javascript';
            js.src = src;
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(js, s);
        }
    }
}

tritonIdSync.load_pixel("https://yield-op-idsync.live.streamtheworld.com/pixel.gif?partner=an&uid=8283896623695571421&pubId=25053");
tritonIdSync.load_script("https://s.update.tritondigital.com/2/163927/analytics.js?cb=1662008212366&c3=Zeno Radio&dt=1639271602866005506000&si=ZenoAds&sr=tritondigital.com&c2=idsync.js&di=www.zeno.fm&de=2&ui=fdfc5bde-e5f3-4cd9-bbe9-a2b29ac05ce4&pp=25053&md=3&ti=386759ef-4825-4b48-be92-6c9671508a55");